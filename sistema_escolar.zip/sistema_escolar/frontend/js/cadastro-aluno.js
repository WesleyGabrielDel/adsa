const form = document.querySelector("form");
const button = document.querySelector("button")

button.addEventListener("click", function (e){
    const formData = new FormData(form)

    const nome = formData.get("nome")
    const email = formData.get("email")
    const password = formData.get("senha")

    if(nome != "" && email != "" && password != ""){
        e.preventDefault();

        console.log("Nome: " + nome)
        console.log("Email: " + email)
        console.log("Password: " + password)

        window.location.href = "./index.html"
    }

    else {
        alert("Preencha todos os campos.")
    }

})