<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de produtos</title>
    <link rel="stylesheet" href="style.css">
</head>

<?php 
    session_start();

    if (!isset($_SESSION["nome_produto"])) {
        $_SESSION["nome_produto"] = "Pacotão de vina";
        $_SESSION["preco_produto"] = "6.60";
        $_SESSION["qtd_estoque"] = 15;
    }

    if($_SERVER["REQUEST_METHOD"] === "POST"){
        if($_SESSION["qtd_estoque"] > 0){
            $_SESSION["qtd_estoque"] -= 1;
        }

        else {
            echo "Produto esgotado!";
        }
    }

?>

<body>
    <h1>Produtos Cadastrados</h1> 
    <table border="1" style="border-collapse: collapse; font-family: Arial, sans-serif; width: 100%; max-width: 600px;">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Preço</th>
                <th>Qtd no Estoque</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td> <?php echo $_SESSION["nome_produto"];?> </td>
                <td> <?php echo "R$ " . $_SESSION["preco_produto"];?> </td>
                <td> <?php echo $_SESSION["qtd_estoque"];?></td>
            </tr>
        </tbody>
    </table>

    <form method="POST">
        <button type="submit">Vender produto</button>
    </form>
</body>
</html>
